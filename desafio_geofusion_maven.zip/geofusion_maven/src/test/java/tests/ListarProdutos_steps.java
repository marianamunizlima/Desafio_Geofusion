package tests;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;

public class ListarProdutos_steps {

	ProdutosPage produtos = new ProdutosPage();

	@Given("^que estou na tela inicial$")
	public void telaInicial() throws Throwable {
		produtos.pagina_inicial();

	}

	@When("^eu preencho os dados do formulário$")
	public void preencherDados() throws Throwable {
		produtos.preencher_dados();
	}

	@Then("^eu posso visualizar a tela de Consulta de Produtos$")
	public void consultaProdutos() throws Throwable {
		produtos.consulta_produtos();
	}

}
