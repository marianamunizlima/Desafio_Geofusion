package tests;

import java.util.NoSuchElementException;
import java.util.Random;

import org.openqa.selenium.WebElement;

public class Helpers {

	public String gerar_nome() {
		char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		StringBuilder sb = new StringBuilder(20);
		Random random = new Random();
		for (int i = 0; i < 20; i++) {
			char c = chars[random.nextInt(chars.length)];
			sb.append(c);
		}
		String nome = sb.toString();

		return nome;

	}
	
	public boolean isElementDisplayed(WebElement element) {
	    try {
	         return element.isDisplayed();
	        } catch(NoSuchElementException e) {
	         return false;
	    }
	}


}
