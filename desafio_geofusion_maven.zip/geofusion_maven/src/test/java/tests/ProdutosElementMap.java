package tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ProdutosElementMap {
	

	protected  WebDriver driver = new ChromeDriver();
	private WebDriverWait wait = new WebDriverWait(driver, 5);
	private Helpers helper = new Helpers();

	public void pagina_inicial() {
		driver.manage().window().maximize();
		driver.get("http://desafio.geofusion.tech");
		
	}

	public void preencher_dados() {
		WebElement nome = driver.findElement(By.id("owner"));
		WebElement btn_ok = driver.findElement(By.cssSelector("button[ng-click = 'setOwner(ownerName)']"));
		nome.sendKeys(helper.gerar_nome());
		btn_ok.click();
	}

	public boolean consulta_produtos() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main")));
		WebElement lista_produtos = driver.findElement(By.id("main"));
		boolean isPresent = helper.isElementDisplayed(lista_produtos);

		return isPresent;

	}

	public void cadastrar_produto() {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		WebElement btn_novo_produto = driver.findElement(By.linkText("Novo Produto"));
		btn_novo_produto.click();
	}
	

}
