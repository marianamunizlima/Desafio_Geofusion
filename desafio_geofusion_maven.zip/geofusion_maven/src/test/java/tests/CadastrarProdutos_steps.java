package tests;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;

public class CadastrarProdutos_steps {

	ProdutosPage produtos = new ProdutosPage();

	@Given("^que estou na tela de Cadastro de Produtos$")

	public void paginaCadastroProdutos() throws Throwable {
		produtos.cadastrar_produto();
	}

	@When("^eu cadastro os dados do produto$")
	public void cadastrarProduto() throws Throwable {
	}

	@Then("^eu posso visualizar o produto cadastrado$")
	public void eu_posso_visualizar_o_produto_cadastrado() throws Throwable {

	}

}
